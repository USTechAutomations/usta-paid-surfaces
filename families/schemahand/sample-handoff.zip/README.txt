SchemaHand worked example

This archive is synthetic and contains no customer data. It is usable without a key.
Start with source.sql if you want to check the input. It is parsed locally by the browser tool; SchemaHand does not connect to a database or execute DDL.
Open handoff.html in a browser. Open a table under Editable notes, edit a note, then select Save edited copy. Open that saved HTML to confirm the note remains. Use the browser print command to print or save the printable table views as PDF.
dictionary.csv describes schema metadata: tables, columns, keys and SQL comments. It is not a customer, order, or destination-import data export.
manifest.json records deterministic input, tool and output hashes plus parsed counts. This fixture has 3 unknown statements; unsupported statements are counted, not executed.
